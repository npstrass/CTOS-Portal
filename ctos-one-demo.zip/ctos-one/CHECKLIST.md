# CTOS One demo checklist

Work through this once in Chrome at 1440 wide, then the phone section. Tick each line.
Start from `login.html`. After any test that changes data, "Reset demo data" in the account menu puts it back.

## Setup
- [ ] `assets/config.js` has the CARTO key and `MAP_PROVIDER: 'carto'`; map loads in the Paper style with no watermark
- [ ] Hard refresh once (Ctrl/Cmd+Shift+R) so no old CSS or JS is cached
- [ ] Browser console shows no red errors and no "assert" lines on any page (the data reconciliation checks)

## Sign in (login.html)
- [ ] Sign in as Mike (established customer) with the form
- [ ] Demo account buttons: Mike, Taylor (new customer), Sarah (CTOS employee) each land on Home
- [ ] Opening any page while signed out redirects to login

## Shell (every page)
- [ ] Sidebar wordmark, tagline, toggle, search, bell and account button sit on one line
- [ ] Collapse nav (button or `[` key): rail shows the "1" mark, icons with tooltips; state persists across pages
- [ ] Search `/` focuses; type "IMT" (component), "Q-10422" (quote), "Garrisonville" (site), "INV-20461" (invoice); arrow keys move through results; Enter opens
- [ ] Bell: items link to their page; Mark all as read clears the dot; tabs filter
- [ ] Account menu: name and role, links, Switch account, Reset demo data, Sign out; Escape closes
- [ ] Skip to content link appears on first Tab press

## Home (index.html)
- [ ] Greeting, hero with the storm-season message, hero stats
- [ ] Quick actions: View my fleet, Schedule service (opens drawer), Order parts, View reports
- [ ] Alerts list reflects live data (approve an estimate on Service and the count drops here)
- [ ] Upcoming service shows booked appointments; news cards open the article; View all opens News

## Fleet (fleet.html)
- [ ] Finding sentence names #1058 (fault) and #1081 (idle)
- [ ] Map: geofence circles, pins in state colours, only the fault pulses; labels appear when zoomed to a region; clicking a label or circle opens the site
- [ ] Needs attention: Schedule diagnostic books #1058 and clears the row; Message driver clears the idle row
- [ ] My own fleet / Rental fleet tabs above the filters; rental tab shows R-418 due back with Schedule return
- [ ] Table columns are Unit, Status, Location, Next service (days until, red when within a week or overdue), Schedule; no fuel or odometer
- [ ] Upcoming service panel lists units soonest first; Import from spreadsheet opens from the panel header
- [ ] Click a unit number: drawer with components, inspections, campaigns, parts, events, history, documents; "Open unit page" works
- [ ] Sites and projects panel counts match the map; Recent events include arrivals
- [ ] Open full map, Manage fleet, All units links

## Full map (map.html)
- [ ] Units tab: hover a row highlights the pin; click pans; double-click opens the unit
- [ ] Sites tab: click pans to the site; double-click opens it; Add a site places by clicking the map
- [ ] Legend in the rail matches pin colours
- [ ] Drawer opens above the map (not behind it)

## Unit page (unit.html?u=1104)
- [ ] Title and finding; five stats (odometer, boom hours, fuel, inspections due, campaigns)
- [ ] Overview: components table (chassis, body, crane, compressor) with serials and warranty; events; parts on order
- [ ] Inspections & title: ASME B30.5 record, campaigns, title and MSO; FET points to the account
- [ ] Overview opens with Upcoming service: next PM with miles left, booked appointments, next two inspections, each bookable
- [ ] Parts for this unit: Add puts "Hoist cable · Unit #1104" in the cart
- [ ] Documents: add a document; it appears and feeds Coming due
- [ ] Also try `unit.html?u=1042` (aerial) and `unit.html?u=1081` (digger derrick, bought elsewhere)

## Manage fleet (fleet-manage.html)
- [ ] Table with type, VIN, source, telematics, driver
- [ ] Add a vehicle: Where it came from starts blank; add with body and crane; it appears here, on Fleet, on the map and in search; duplicate unit number refused
- [ ] Edit a unit; Retire a unit (confirm)
- [ ] Import from a spreadsheet: Paste a sample, Preview, add; a bad row is flagged and skipped
- [ ] Title and tax, Documents expiring, Drivers panels

## Service (service.html)
- [ ] Schedule service: type to search a unit (number, model, driver) and pick it; the closest CTOS shop is preselected with its distance; switch to Field service and a site picker replaces the shop
- [ ] In the shop lists the three work orders with stage and estimate; no approval queue; the drawer shows the estimate with no Approve button
- [ ] Inspections due shows #1117 crane overdue; Book it prefills the job
- [ ] Recalls and campaigns: chassis and aerial items for #1058 together; Schedule prefills
- [ ] Week strip shows #1104 and #1145 in the shop; booking adds to the right day
- [ ] Coming due by miles; Documents due; history table with component column

## Orders (parts.html)
- [ ] Parts: open orders table, order drawer with tracking stages, Reorder these items
- [ ] Reorder list Add builds the cart; New order shows the cart with quantity steppers; Place order adds Order 48232 as Processing
- [ ] Trucks: Quotes panel shows Q-10422 with two lines; accept creates three orders (qty 2 + 1) on the On order table below, each tagged with its Q and QL
- [ ] Request a quote with two configurations
- [ ] Rentals: Schedule return on R-418, Extend on another
- [ ] Freight: book the F-3310 quote; request a new move (no Salesforce references here)
- [ ] Tabs are addressable: parts.html#rentals opens on Rentals

## Billing (billing.html)
- [ ] Open invoices with due-soon highlighted; Pay one; Pay all; empty state afterwards
- [ ] Invoice drawer splits parts (linked order) and labor
- [ ] Rental charges, Autopay toggle persists, payment methods

## Reports (reports.html)
- [ ] Five reports render from live data; Inspection and campaign compliance lists overdue first; Export shows a toast

## Your team (team.html)
- [ ] Account tax documents panel: FET exemption and IFTA at account level
- [ ] Portal users: invite one (appears as Invited); edit a role; remove access
- [ ] Drivers: add one and assign to a unit; the unit's driver updates on Fleet
- [ ] CTOS team cards, locations, account facts

## Support (support.html)
- [ ] Open request shows; New request creates TK-5122 and a notification

## News (news.html)
- [ ] Three articles; list selection and hash routing; Schedule service from an article

## New customer (sign in as Taylor)
- [ ] Home shows the setup list at 0 of 4; every other page shows empty states, none broken
- [ ] Add a truck from the list; count goes to 2 of 4; invite a user; 3 of 4

## CTOS employee (sign in as Sarah)
- [ ] Dark bar at top, account shows "viewing as CTOS"
- [ ] Home has the For CTOS staff panel with account notes; add a note
- [ ] Service: work-order drawer shows Send approval reminder, no Approve button
- [ ] Orders: Q-10419 drawer shows Send quote to customer; sending prices the lines and notifies

## Phone (narrow the window under 900px)
- [ ] Sidebar hidden; bottom tab bar; top bar with mark, search icon, bell, avatar
- [ ] Drawers rise from the bottom; forms usable; tables scroll sideways
- [ ] Map page: list above the map; map still usable

## Known limits (say these out loud rather than discover them live)
- Data is sample data kept in the browser; Reset demo data restores it
- The BOM is keyed by component model; production would key by serial range
- Campaign applicability is listed per unit by hand; production matches on serial
- The Google Maps option draws static markers (no pulse); Mapbox is untested with a key
